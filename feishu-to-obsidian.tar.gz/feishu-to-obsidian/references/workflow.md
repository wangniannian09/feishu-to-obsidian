# 飞书内容导入 Obsidian 工作流

## 完整流程

```
用户输入飞书链接
    ↓
识别链接类型
    ↓
调用对应飞书 CLI 命令
    ↓
获取内容（Markdown/XML）
    ↓
清理格式、提取元数据
    ↓
生成文件名（标题-日期.md）
    ↓
保存到 Obsidian vault
    ↓
确认保存成功
```

## 链接类型识别

| URL 模式 | 类型 | 处理命令 |
|----------|------|----------|
| `https://*.feishu.cn/docx/*` | 云文档 | `docs +fetch` |
| `https://*.feishu.cn/wiki/*` | 知识库文档 | `docs +fetch` |
| `https://*.feishu.cn/minutes/*` | 妙记 | `vc +notes` |
| `https://*.feishu.cn/sheets/*` | 电子表格 | `sheets +export` |
| `https://*.feishu.cn/base/*` | 多维表格 | `base records list` |

## 内容清理规则

### 移除的标签

- `<readonly-block type="isv">`
- `<readonly-block type="meeting_notes_qa">`
- 空的 `<cite>` 标签（保留有内容的）

### 保留的标签

- `<blockquote>` → Markdown 引用
- `<grid>` → Markdown 表格或保留
- `<whiteboard>` → 转为链接说明

### 元数据提取

从内容中提取：
- **标题**：`<title>` 标签或文档标题
- **日期**：会议时间、创建时间或 URL 推断
- **参会人**：`<cite type="user">` 标签
- **相关链接**：文档内嵌入的其他飞书链接

## 文件命名

```javascript
// 规则：标题-日期.md
// 示例：组织AI化推进工作脑暴会-2026-05-06.md

function generateFilename(title, date) {
    const cleanTitle = title.replace(/[\\/:*?"<>|]/g, '');
    const dateStr = formatDate(date); // YYYY-MM-DD
    return `${cleanTitle}-${dateStr}.md`;
}
```

## Obsidian Front Matter（可选）

可在文件头部添加 YAML front matter：

```yaml
---
source: feishu
url: https://xxx.feishu.cn/docx/xxx
type: meeting_notes
date: 2026-05-06
tags: [会议, AI, 组织]
---
```

## 错误处理

| 错误类型 | 处理方式 |
|---------|---------|
| 权限不足 | 提示用户 `lark-cli auth login` |
| 文档不存在 | 确认 URL 正确性 |
| Vault 路径不存在 | 创建目录或提示用户 |
| 文件名冲突 | 添加时间戳或序号 |
