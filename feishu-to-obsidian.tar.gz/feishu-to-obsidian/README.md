# 飞书内容导入 Obsidian Skill

> 将飞书云文档、妙记、电子表格等内容一键导入到本地 Obsidian vault

## 功能

- 支持飞书云文档（docx）
- 支持飞书妙记（minutes）
- 支持飞书电子表格（sheets）
- 自动清理格式、提取元数据
- 按规则命名文件

## 安装

```bash
npx skills add wangniannian09/feishu-to-obsidian -g
```

## 前置要求

- 已安装 `lark-cli`
- 已登录飞书：`lark-cli auth login`
- 有对应飞书内容的访问权限

## 使用方法

直接给 AI 一个飞书链接：

```
帮我把这个飞书文档保存到 Obsidian：
https://xxx.feishu.cn/docx/Nna0dFSE9oXHHYxO245cAI8hn1g
```

AI 会自动：
1. 识别链接类型
2. 获取内容
3. 清理格式
4. 保存到你的 Obsidian vault

## 配置

编辑 `config.json` 自定义设置：

```json
{
  "vault_path": "~/Documents/Obsidian Vault/",
  "naming_rule": "title-date",
  "create_folder": false,
  "add_frontmatter": true
}
```

## 文件命名规则

| 规则 | 格式 | 示例 |
|------|------|------|
| `title-date` | 标题-日期.md | 组织AI化推进-2026-05-06.md |
| `date-title` | 日期-标题.md | 2026-05-06-组织AI化推进.md |
| `title` | 标题.md | 组织AI化推进.md |

## License

MIT
