---
name: feishu-to-obsidian
version: 1.0.0
description: "飞书内容导入 Obsidian：支持飞书云文档（docx）、妙记（minutes）、电子表格等飞书内容自动获取并保存到本地 Obsidian vault"
---

# 飞书内容导入 Obsidian

将飞书云空间中的内容自动获取并保存到本地 Obsidian vault，用于知识管理和个人笔记归档。

## 适用场景

当用户需要将飞书内容导入到 Obsidian 时使用本 skill：
- 飞书云文档（docx）→ Obsidian Markdown
- 飞书妙记（minutes）→ Obsidian 会议纪要
- 飞书电子表格（sheets）→ Obsidian Markdown 表格
- 飞书多维表格（Base）→ Obsidian Markdown

## 前置条件

**CRITICAL — 执行前 MUST 先用 Read 工具读取 [`../lark-shared/SKILL.md`](../lark-shared/SKILL.md)**
了解飞书 CLI 的认证、权限处理、全局参数和安全规则。

## 核心流程

### 1. 获取飞书内容

根据用户提供的飞书链接类型，调用对应的飞书 CLI 命令：

| 内容类型 | 识别特征 | 命令 |
|---------|---------|------|
| 云文档 | `/docx/` 或 `/wiki/` | `lark-cli docs +fetch --api-version v2 --doc <url> --doc-format markdown` |
| 妙记 | `/minutes/` | `lark-cli vc +notes --minute-tokens <token>` |
| 电子表格 | `/sheets/` | `lark-cli sheets +export --token <token> --format markdown` |
| 多维表格 | `/base/` | `lark-cli base records list ...` |

### 2. 处理内容

- 清理飞书特有标签（如 `<readonly-block>`、`<cite>` 等）
- 保留核心内容结构
- 提取元数据（标题、日期、参会人等）

### 3. 保存到 Obsidian

默认 vault 路径：`~/Documents/Obsidian Vault/`

文件命名规则：`标题-日期.md`

如：`组织AI化推进工作脑暴会-2026-05-06.md`

## 使用示例

```bash
# 用户给一个飞书文档链接
# AI 自动识别类型 → 获取内容 → 清理格式 → 保存到 Obsidian
```

## Shortcuts

无快捷命令，本 skill 主要作为 AI Agent 的编排逻辑使用。

## 配置

用户首次使用时，需要确认 Obsidian vault 路径：
- 默认：`~/Documents/Obsidian Vault/`
- 可自定义：在 `~/.claude/skills/feishu-to-obsidian/config.json` 中配置

## 参数

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `vault_path` | Obsidian vault 路径 | `~/Documents/Obsidian Vault/` |
| `naming_rule` | 文件命名规则 | `title-date` |
| `create_folder` | 是否创建子文件夹 | `false` |

## 注意事项

- 飞书 CLI 需已登录：`lark-cli auth login`
- 确保有对应内容的访问权限
- 大文件可能需要较长处理时间

## 依赖技能

- [`lark-doc`](../lark-doc/SKILL.md) — 云文档操作
- [`lark-minutes`](../lark-minutes/SKILL.md) — 妙记操作
- [`lark-sheets`](../lark-sheets/SKILL.md) — 电子表格操作
- [`lark-base`](../lark-base/SKILL.md) — 多维表格操作
